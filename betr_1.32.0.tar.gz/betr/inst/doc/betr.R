### R code from vignette source 'betr.Rnw'

###################################################
### code chunk number 1: setup
###################################################
options(width=60)
options(continue=" ")
options(prompt="R> ")


###################################################
### code chunk number 2: loadData
###################################################
library(betr)
library(Biobase)
data("timeEset")
pData(timeEset)[1:15,]


###################################################
### code chunk number 3: runBETR
###################################################
prob <- betr(eset=timeEset, cond=pData(timeEset)$strain, 
    timepoint=pData(timeEset)$time, replicate=pData(timeEset)$rep, alpha=0.05)
head(prob)    


###################################################
### code chunk number 4: betr.Rnw:76-77
###################################################
sessionInfo()


