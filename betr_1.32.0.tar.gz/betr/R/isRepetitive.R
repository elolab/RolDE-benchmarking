`isRepetitive` <- function(x) {
    n <- length(x)
    retval <- FALSE
    if (is.list(x)) {
        if (n>2) 
            for (i in 1:(n-1)){
                if (setequal(x[[n]], x[[i]]))
                    return(TRUE)
            }
    } else {
        n <- length(x)
        if (n>2) 
            for (i in 1:(n-1)){
                if (x[n] == x[i])
                    return(TRUE)
            }
    }
    FALSE 
}

